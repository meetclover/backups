from alipay import AliPay

'''
请前往 开放平台 https://openhome.alipay.com/ 注册自研服务应用 ｜ 注意：不要注册第三方应用，权限不足
路径：我的应用>自研服务>网页&移动应用
1、添加当面付能力
2、接口加签方式：公钥>填写自己生成的应用公钥 (RSA2)
3、配置下面的信息，大功告成！
'''

# 配置区域

# appid
appid="2021003157620316"

# 应用私钥
app_private_key_string = "-----BEGIN RSA PRIVATE KEY-----\nMIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCyocWwaq9WGDzA2TeblGFxv/Hx0nmEhbEfmpNAOq3xf0m5kkb1heRKPSn4F2/VfN9SxBz4o4hWJtSAvYc4omMYAiVdIatTMX1+PTMCyokD+sAjnir16P4K+EPs/2ORwBPZM2HmwmOQOwlzqtMhRuRgFlpKJTMMRJI9Jk+9Wsw/XmaXTVoScjvaU9OhZcrMZlHBn0CS6B6i26RDBHpts9ElIL5Y+2wzI+GYJJMbuEbRhYvxDgpKVLqmNN2hasEmelrpVnreAl1T7NxMslA5BKqNTdfuUk/6xJcFOlNHwbUQ9BSr+SctjI4b2igaWksBagkHkk9ntGrvbEZ8XAkzyyehAgMBAAECggEAL2Y5vLwyVlgMFugMl13iFXrnSlGdKQsImug7Vnm7mi86cuFbrt6eWwyrzEb7x9xgreeYAGn0TVf0X0zrSp3cSYyYOYQrn+Gr+QloNb9kaAfrYAgiQipW7rY93+9Mjmo3WhUGT2MZZDYmJekYKOZUxyJnRvFkAEdZvpwh4I7tT4rcrcZpnLvHJ58EJ+NGxjm8BYE1QPuFMYY+SDTruzZiSKj1iB8UCK9r5upPM6+EKgfUM3nJb0Y/jHddeo2s9+kZXBACwL/0J7P8FwBho3D+M4SDrETTC6d4ccdhtu1XAiWEWU/QVqiNZQl259U1IRalkK1v4zlZVEfP3TTKkropoQKBgQDymKFhRO1oH/VcWHwnFYS0hlCXUCoDmsYDJiv0sWFB7SjsBe/3dqN6SrdF2d7hVjuPy/pwui2s3dBJJnHGRwhjmDXxEEEH4zuqbJ/BuXFlpR1kk974aRge1ZAmlaSxrtteQKfP3BSiqTelgBP7tHRqJJEnJ2Lds6ks3Dvo80hiLQKBgQC8gGhSnTaSQeOT1JhH68CEe2KGA/1nXB7vmVbUlHS/z/W6ddYiRa5Ll6XMtm4F3Cdql8EPWILuTG2AdfrXhNIxp32IwxYzyvW9RQXbjRwBCQG82+aPPLmwBQj03miIjs+/W4E/q1Ac8jmFJR9X88hFIJzAQGsKXkfw82ho7CXnxQKBgBGoLkbIH4dunAsmnZKyrD//bqo0uXodr7/W7WgX6P5FZq8XF4opZmimO4SoAOLhxeAHdqjxxBVK57gLRkiqLuAg2fw7tKAAV/1lfpM5DhnZ1LPXV2k5LPpBjQZh6eTM10aa6hvk5tOYAWbYVZwCXF7FXpM8+KMuSmfrd6jS3DfZAoGBAJEFaT1F3loffuqYwJ90bKSAGIhqQWZnpRVIr1jU7g0z/ST6y0eKvFFD1jbskzDG8zw6jDk2K2USP5x5KAbvFJdG+HljPY2TNAPtOlhy83yIZWHa/EJuwZz+AqoBAgMte/8IcyN8tSHP6RjaOob78rPcJzxxUuijKE3jtgwiwfbRAoGAWF/1g2HjSVu+//hMQBO0Q8BO+JsRM0+YoAVHBnm8ssE1qskJEq0lMf5zbyEdQk2YjFEsPTS9PpzPUo1mGu9GIyvw8okfXS2tmmwojXzAPecHlCJIxsYXFDh88xYHTmqu3Ko5fNMzBtcEcZg1JrbC1YQK5ecXDsTeF4DXSXs0sYc=\n-----END RSA PRIVATE KEY-----"

# 支付宝公钥，验证支付宝回传消息使用，不是你自己的公钥,
alipay_public_key_string = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA1nLkTNmEA4wzQtitM2x3lgI2zN2GdHzzgjbSnua4b0Z3XtqBwA5wEqRcC5wvazwSA0MMwAUEw7NoMF2az1bNic/3rzxblvhCvx2W7tuOMsFHA0UeYevONA13n/r+lJslRJkuyaqDDaG+jyGnpvhSo6+NIOub9VMZwiHKGvueU4ZIhBoPYzZbXu3Gv67ozpqCqJr9kZNaAfTznsHmMovHpURDReY+PNIP0uIUQ7cHWByEXxgoa0fENXT1ekHzcqPRuyzbPk41iElVyxs/JFdiN8FVxcZJNkDeljFY52fKVDI4+qGQcTu1Sa2LSxXAKcbuatfVFnfCSoAgocLojy0lSQIDAQAB\n-----END PUBLIC KEY-----"

# 示例格式 注意\n
# alipay_public_key_string = "-----BEGIN PUBLIC KEY-----\nMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAw9QbJi++cm2HjinPpllj3Hmep8nxO9MVu0BTSP1XM1wF666g6sTwQ0VXyRJENpYEs0KFE/XnMKilV/+uQY7xH4SqcdX2T4C5DkiWJ4egD2Tk3yLH6fjq7TqCsMqG3osfk6U93H+XdiWKKff+nwQ6LnUIEYWoMIh/fyqTYtlKzBTUg8nJWoqfkspFWlt69PrbosbAFWY7vp+3CapO/o4Qw+thuhGKAvEZWmNy3hUnnThStos+T8qI/Qqs5f9zb9wIDAQAB\n-----END PUBLIC KEY-----"

# 订单超时时间
# m：分钟，只可为整数，建议与config配置的超时时间一致
PAY_TIMEOUT = '5m'

try:
    alipay = AliPay(
        appid=appid,
        app_notify_url=None,  # 默认回调url，不要改
        app_private_key_string=app_private_key_string,
        alipay_public_key_string=alipay_public_key_string,
        sign_type="RSA2",
    )
except Exception as e:
    print(e)
    print('Alipay对象创建失败，请检查公钥和密钥是否配置正确')


def submit(price, subject, trade_id):
    try:
        order_string = alipay.api_alipay_trade_precreate(
            subject=subject,
            out_trade_no=trade_id,
            total_amount=price,
            qr_code_timeout_express=PAY_TIMEOUT
        )
        print(order_string)
        if order_string['msg'] == 'Success':
            qr_code = order_string['qr_code']
            print(qr_code)
            return_data = {
                'status': 'Success',
                'type': 'qr_code',  # url / qr_code
                'data': 'http://api.qrserver.com/v1/create-qr-code/?data={}&bgcolor=FFFFCB'.format(qr_code)     # 自行对接二维码API
            }
            return return_data
        else:
            print(order_string['msg'])
            return_data = {
                'status': 'Failed',
                'data': 'API请求失败'
            }
            return return_data
    except Exception as e:
        print(e)
        print('支付宝当面付API请求失败')
        return_data = {
            'status': 'Failed',
            'data': 'API请求失败'
        }
        return return_data


def query(out_trade_no):
    try:
        result = alipay.api_alipay_trade_query(out_trade_no=out_trade_no)
        if result.get("trade_status", "") == "TRADE_SUCCESS":
            print(str(result))
            print('支付宝当面付｜用户支付成功')
            return '支付成功'
        else:
            print(str(result))
            print('支付宝当面付｜用户支付失败')
            return '支付失败'
    except Exception as e:
        print(e)
        print(str(result))
        print('支付宝当面付｜请求失败')
        return 'API请求失败'


def cancel(out_trade_no):
    try:
        alipay.api_alipay_trade_cancel(out_trade_no=out_trade_no)
    except Exception as e:
        print(e)