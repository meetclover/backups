
# 支付超时时间(秒)
PAY_TIMEOUT = 300
# BOT API
TOKEN = '1222117547:AAGWJ43CJ-4aejeoICdQ2t01wWMiIAOgJKc'
# ADMIN ID
ADMIN_ID = [744255323]

# 管理员命令
ADMIN_COMMAND_START = 'iadmin'
ADMIN_COMMAND_QUIT = 'icancel'

# 支持的支付方式
PAYMENT_METHOD = {
    'epay': '支付宝/微信/QQ',
    'alifacepay': '支付宝当面付',
}

# 当前版本
VERSION = '1.3.3'
